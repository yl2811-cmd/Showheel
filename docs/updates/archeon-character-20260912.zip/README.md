# Character update · 2026-09-12

Showheel contains the changed source files. compressed-overlay contains matching compressed page and image assets for an existing Showheel build; it is not a standalone website. SKBS contains the unchanged, synchronized Chinese source. The existing build exports /Character as Character.html and generates its route mapping automatically. See Showheel/docs/character for verification and the current publication boundary.
