# Character tab placement correction

Character is now tab 06 inside Archeon Atlas, immediately after Federation. This archive is an overlay for an existing Showheel site, not a standalone site. It includes source changes, compressed page and portrait assets, and the synchronized Chinese manuscript. See Showheel/docs/character for validation details.
