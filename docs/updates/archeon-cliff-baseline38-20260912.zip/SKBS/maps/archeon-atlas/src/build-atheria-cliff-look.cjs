'use strict';
// Sidecar ownership only: accepted positions, normals, colours and indices stay intact.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const A=require('./atheria-region-model.cjs'),G=require('./atheria-geography.cjs');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function build(root=path.resolve(__dirname,'..'),dir=path.join(root,'atheria-assets')){
 const manifest=JSON.parse(fs.readFileSync(path.join(dir,'manifest.json'))),records={},runs=[],stats={regional:[0,0,0],lods:[0,0,0,0],detailVertices:0,collarVertices:0,centralRegionalVertices:[0,0,0,0],files:0};
 let offset=0;
 const get=file=>fs.readFileSync(fs.existsSync(path.join(dir,file))?path.join(dir,file):path.join(root,'atheria-assets',file));
 function save(key,ids,nv,sourceSha256){
  if(!ids.length)return;ids.sort((a,b)=>a-b);const ranges=[];let start=ids[0],end=start+1;
  for(let j=1;j<ids.length;j++){const i=ids[j];if(i<end)continue;if(i===end)end++;else{ranges.push(start,end-start);start=i;end=i+1;}}ranges.push(start,end-start);
  const data=Buffer.alloc(ranges.length*4);ranges.forEach((n,i)=>data.writeUInt32LE(n,i*4));records[key]={offset,rangeCount:ranges.length/2,vertices:nv,selected:ids.length,sourceSha256};offset+=data.length;runs.push(data);stats.files++;
 }
 function region(buffer,tile,lod){
  if(buffer.toString('ascii',0,4)!=='AVX1')throw Error('Invalid regional mesh');
  const nv=buffer.readUInt32LE(4),ni=buffer.readUInt32LE(8),normal=16+nv*12,color=normal+nv*3,index=color+nv*3,cell=tile.levels[lod].cellM,ids=[];
  const pos=i=>{const x=buffer.readFloatLE(16+i*12)+(tile?.x||0),z=buffer.readFloatLE(24+i*12)+(tile?.z||0);return[x,buffer.readFloatLE(20+i*12)-A.curvature(x,z),z];};
  for(let j=0;j+5<ni;j+=3){const face=Array.from({length:6},(_,k)=>buffer.readUInt32LE(index+(j+k)*4)),i=face[0];if(face[1]!==i+1||face[2]!==i+2||face[3]!==i||face[4]!==i+2||face[5]!==i+3)continue;j+=3;
   const n=[0,1,2].map(k=>buffer.readInt8(normal+i*3+k));if(n[1]!==0||Math.abs(n[0])+Math.abs(n[2])!==127)continue;
   if([1,2,3].some(q=>[0,1,2].some(k=>buffer[color+(i+q)*3+k]!==buffer[color+i*3+k])))continue;
   const p=[0,1,2,3].map(q=>pos(i+q)),a=Math.min(...p.map(p=>p[1])),b=Math.max(...p.map(p=>p[1])),x=p.reduce((s,p)=>s+p[0],0)/4,z=p.reduce((s,p)=>s+p[2],0)/4,y=(a+b)/2;
   if(y< -180||y>490||Math.abs(x)>14200)continue;
   const levels=[0,1,2].filter(l=>{const c=G.cliffSample(x,z,l);return c.strength>.16&&Math.abs(c.distance)<Math.max(85,cell*2.5);});if(!levels.length)continue;
   const xx=tile.x+(Math.floor((Math.min(...p.map(p=>p[0]))-tile.x)/cell+.001)-(n[0]===127?1:0))*cell,zz=tile.z+(Math.floor((Math.min(...p.map(p=>p[2]))-tile.z)/cell+.001)-(n[2]===127?1:0))*cell;
   const v=.88+.14*A.noise(xx/220,(a+zz/20)/60),old=A.colors.stone.map((c,k)=>Math.round(A.clamp(A.mix(c,A.colors.basalt[k],.13+.14*Math.sin(a*.12+xx*.001))*v)*255));
   const lifted=old.map(v=>Math.min(255,Math.round(v*(1+.10*(1-A.smooth(7500,11000,Math.abs(x)))))));
   if(![old,lifted].some(c=>c.every((v,k)=>Math.abs(v-buffer[color+i*3+k])<=1)))continue;
   const level=levels.sort((a,b)=>Math.abs(G.cliffSample(x,z,a).distance)-Math.abs(G.cliffSample(x,z,b).distance))[0];
   ids.push(i,i+1,i+2,i+3);if(Math.abs(x)<128&&Math.abs(z)<128)stats.centralRegionalVertices[lod]+=4;stats.regional[level]+=4;stats.lods[lod]+=4;
  }
  return {ids,nv};
 }
 for(const tile of manifest.tiles)for(let lod=0;lod<tile.levels.length;lod++){
  const r=tile.levels[lod],buffer=get(r.file);if(hash(buffer)!==r.sha256)throw Error('Source hash mismatch: '+r.file);
  const {ids,nv}=region(buffer,tile,lod);save(r.file,ids,nv,r.sha256);
 }
 // The central regional terrain remains tinted at a distance. The viewer clips
 // it away only while the separately shaded Eyrie high detail is visible.
 // High-detail meshes, the collar and architecture proxies remain excluded.
 if(stats.regional.some(n=>n===0)||stats.lods.some(n=>n===0))throw Error('Incomplete regional cliff ownership');
 const binary=Buffer.concat(runs),configPath=path.join(dir,'cliff-look.json'),acceptedConfig=path.join(root,'atheria-assets/cliff-look.json'),previousPath=fs.existsSync(configPath)?configPath:acceptedConfig,previous=fs.existsSync(previousPath)?JSON.parse(fs.readFileSync(previousPath)):null;
 const config={version:1,baselineRevision:previous?.baselineRevision||'atheria-cliff-white-2',defaultValue:previous?.defaultValue??38,curveRevision:'warm-rock-1',tone:'warm-rock-white',range:[0,100],step:1,sourceBuild:manifest.buildId,scope:'regional-cliffs-only',scopeRevision:3,curve:{gain:2.4,contrast:1.3,neutralMix:.65,warmth:[1.045,1.01,.945],pivot:.28,shoulder:.72,ceiling:.94},records,stats};
 fs.writeFileSync(path.join(dir,'cliff-masks.bin'),binary);fs.writeFileSync(configPath,JSON.stringify(config));
 manifest.cliffLook={file:'cliff-look.json',bytes:fs.statSync(configPath).size,sha256:hash(fs.readFileSync(configPath)),masks:{file:'cliff-masks.bin',bytes:binary.length,sha256:hash(binary)}};
 fs.writeFileSync(path.join(dir,'manifest.json'),JSON.stringify(manifest));fs.writeFileSync(path.join(dir,'manifest.js'),'window.ATHERIA_REGION_MANIFEST='+JSON.stringify(manifest)+';');
 return{...stats,maskBytes:binary.length,configBytes:manifest.cliffLook.bytes,baselineRevision:config.baselineRevision,defaultValue:config.defaultValue};
}
module.exports={build};if(require.main===module)console.log(JSON.stringify(build(process.argv[2]),null,2));
