'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),d3=require('../vendor/d3.v7.min.js'),A=require('./atheria-region-model.cjs'),site=require('./eyrie-site.cjs'),G=require('./atheria-geography.cjs'),Life=require('./atheria-life-blocks.cjs');
const root=path.resolve(__dirname,'..'),out=path.resolve(process.env.ATHERIA_OUT||path.join(root,'../../review/atheria-region-20260909/candidate/atheria-assets'));
const atlasPath=path.resolve(process.env.ATHERIA_ATLAS||path.join(root,'data/atlas.json'));
const refineMode=process.argv.includes('--refine-buildings'),refineBaseline=refineMode&&path.resolve(process.env.ATHERIA_REFINE_BASELINE||path.join(root,'atheria-assets'));
const accepted=refineMode&&JSON.parse(fs.readFileSync(path.join(refineBaseline,'manifest.json')));
if(refineMode&&out===refineBaseline)throw Error('Building refinement requires a separate candidate output');
fs.mkdirSync(out,{recursive:true});const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),atlas=JSON.parse(fs.readFileSync(atlasPath));
const inputSnapshot=Object.fromEntries([['cliffFinish',path.join(__dirname,'atheria-cliff-finish.cjs')],['model',path.join(__dirname,'atheria-region-model.cjs')],['generator',__filename],['landscape',path.join(__dirname,'atheria-landscape.cjs')],['publicGround',path.join(__dirname,'atheria-public-ground.cjs')],['atlas',atlasPath],['eyrie',path.join(root,'eyrie-assets/manifest.json')],...['atheria-geography.cjs','atheria-water.cjs','atheria-life-blocks.cjs','atheria-transport.cjs','atheria-ground-network.cjs','atheria-river-curves.cjs','atheria-rail-shape.cjs','atheria-terrace-water.cjs','atheria-upland.cjs','atheria-eyrie-detail.cjs','atheria-woodland.cjs','atheria-eyrie-transition.cjs'].map(f=>[f,path.join(__dirname,f)]),...['atheria-native-baseline.f32','atheria-layout-seed.json','atheria-river-seed.json','atheria-coarse-baseline.json'].map(f=>[f,path.join(root,'data',f)])].map(([key,file])=>[key,{file,sha256:sha(file)}]));
const step=256,size=1025,min=-131072,nativePath=path.join(out,'native-height.f32');
if(refineMode){const file=path.join(__dirname,'atheria-building-refinement.cjs');inputSnapshot.buildingRefinement={file,sha256:sha(file)};}
const frozenNative=path.join(root,'data/atheria-native-baseline.f32');
if(fs.existsSync(frozenNative)&&(!fs.existsSync(nativePath)||sha(nativePath)!==sha(frozenNative)))fs.copyFileSync(frozenNative,nativePath);
if(!fs.existsSync(nativePath)){
 const meta=JSON.parse(fs.readFileSync(path.join(root,'terrain/aethelgard-meta.json'))),c=meta.view,b=c.bounds,proj=d3.geoConicConformal().parallels([15,45]).rotate([12,0]).center([0,28]).fitExtent([[c.box[0],c.box[1]],[c.box[2],c.box[3]]],{type:'Polygon',coordinates:[[[b[0],b[1]],[b[0],b[3]],[b[2],b[3]],[b[2],b[1]],[b[0],b[1]]]]});
 const fd=fs.openSync(path.join(root,'terrain/aethelgard-height.f32'),'r'),buf=Buffer.alloc(4),values=new Float32Array(size*size);
 for(let z=0;z<size;z++)for(let x=0;x<size;x++){const p=proj(A.geo(min+x*step,min+z*step)).map(v=>Math.round(v*meta.scale-.5));fs.readSync(fd,buf,0,4,(p[1]*meta.width+p[0])*4);values[z*size+x]=buf.readFloatLE(0);}
 fs.closeSync(fd);fs.writeFileSync(nativePath,Buffer.from(values.buffer));console.log('Sampled existing continent relief.');
}
const raw=fs.readFileSync(nativePath),nativeGrid=new Float32Array(raw.buffer,raw.byteOffset,raw.length/4);
function native(x,z){const xx=A.clamp((x-min)/step,0,size-1.001),zz=A.clamp((z-min)/step,0,size-1.001),ix=Math.floor(xx),iz=Math.floor(zz),u=xx-ix,v=zz-iz;return A.mix(A.mix(nativeGrid[iz*size+ix],nativeGrid[iz*size+ix+1],u),A.mix(nativeGrid[(iz+1)*size+ix],nativeGrid[(iz+1)*size+ix+1],u),v);}
const onlyTile=process.argv.find(a=>a.startsWith('--tile='))?.slice(7),previousManifest=onlyTile&&JSON.parse(fs.readFileSync(path.join(out,'manifest.json'))),model=A.create({native,atlas,site});let coverage;
if(refineMode){
 const aliases={model:'atheria-region-model.cjs',landscape:'atheria-landscape.cjs',publicGround:'atheria-public-ground.cjs'};
 for(const [key,hash]of Object.entries(accepted.sourceHashes)){
  if(key==='generator'||key==='atheria-eyrie-detail.cjs')continue;
  const file=aliases[key]?path.join(__dirname,aliases[key]):key.endsWith('.cjs')?path.join(__dirname,key):key.endsWith('.json')?path.join(root,'data',key):null;
  if(file&&fs.existsSync(file)&&sha(file)!==hash)throw Error('Accepted regional input changed: '+key);
 }
 if(accepted.sourceHashes.atlas!==sha(atlasPath))throw Error('Accepted atlas changed');
 coverage=JSON.parse(JSON.stringify(accepted.coverage));Object.assign(model.multipliers,coverage.multipliers);Object.assign(model.landscape.cropScale,coverage.fieldAllocation.selectionScale);model.landscape.stats.cropAllocation=coverage.fieldAllocation;
}else if(onlyTile){for(const [key,file]of [['model',path.join(__dirname,'atheria-region-model.cjs')],['generator',__filename],['landscape',path.join(__dirname,'atheria-landscape.cjs')],['atlas',atlasPath],['eyrie',path.join(root,'eyrie-assets/manifest.json')],['native',nativePath],['publicGround',path.join(__dirname,'atheria-public-ground.cjs')],...['atheria-geography.cjs','atheria-water.cjs','atheria-life-blocks.cjs','atheria-transport.cjs','atheria-ground-network.cjs','atheria-river-curves.cjs','atheria-rail-shape.cjs','atheria-terrace-water.cjs','atheria-upland.cjs','atheria-eyrie-detail.cjs','atheria-woodland.cjs','atheria-eyrie-transition.cjs'].map(f=>[f,path.join(__dirname,f)]),...['atheria-native-baseline.f32','atheria-layout-seed.json','atheria-river-seed.json','atheria-coarse-baseline.json'].map(f=>[f,path.join(root,'data',f)])])if(previousManifest.sourceHashes[key]&&previousManifest.sourceHashes[key]!==sha(file))throw Error('Regional inputs changed; full build required before partial rebuild');Object.assign(model.multipliers,previousManifest.coverage.multipliers);coverage=previousManifest.coverage;Object.assign(model.landscape.cropScale,coverage.fieldAllocation.selectionScale);model.landscape.stats.cropAllocation=coverage.fieldAllocation;}
else if(process.env.ATHERIA_COVERAGE_BASELINE){
 const proof=JSON.parse(fs.readFileSync(process.env.ATHERIA_BASELINE_PROOF)),previous=JSON.parse(fs.readFileSync(process.env.ATHERIA_COVERAGE_BASELINE));
 const eligible=proof.files.filter(f=>(f.path.startsWith('src/')&&!['src/build-atheria-region.cjs','src/atheria-eyrie-detail.cjs'].includes(f.path))||f.path.startsWith('data/'));
 for(const f of eligible)if(sha(path.join(root,f.path))!==f.sha256)throw Error('Coverage input changed: '+f.path);
 if(previous.sourceHashes.atlas!==sha(atlasPath))throw Error('Atlas changed; coverage cannot be reused');
 coverage=JSON.parse(JSON.stringify(previous.coverage));Object.assign(model.multipliers,coverage.multipliers);Object.assign(model.landscape.cropScale,coverage.fieldAllocation.selectionScale);model.landscape.stats.cropAllocation=coverage.fieldAllocation;
 console.log('Reusing accepted land-use coverage after '+eligible.length+' unchanged input hashes.');
}else{console.log('Calibrating inhabited and cultivated coverage...');coverage=model.calibrate();}console.log(JSON.stringify(coverage));
const RailShape=require('./atheria-rail-shape.cjs');
const life=Life({model,colors:A.colors,hash:A.hash,noise:A.noise}),transport=model.transport;
const waterBuckets=new Map();
for(const c of model.channels)for(let i=1;i<c.points.length;i++){const a=c.points[i-1],b=c.points[i],width=Math.max(a[3],b[3]),band={a:[a[0],0,a[1]],b:[b[0],0,b[1]],width,reliefM:0,level:Math.min(a[2],b[2])+.25},pad=width/2+1;band.bounds=[Math.min(a[0],b[0])-pad,Math.min(a[1],b[1])-pad,Math.max(a[0],b[0])+pad,Math.max(a[1],b[1])+pad];for(let x=Math.floor(band.bounds[0]/512);x<=Math.floor(band.bounds[2]/512);x++)for(let z=Math.floor(band.bounds[1]/512);z<=Math.floor(band.bounds[3]/512);z++){const k=x+','+z;if(!waterBuckets.has(k))waterBuckets.set(k,[]);waterBuckets.get(k).push(band);}}
function waterBandsAt(x,z,w,d=w){const set=new Set();for(let i=Math.floor(x/512);i<=Math.floor((x+w)/512);i++)for(let j=Math.floor(z/512);j<=Math.floor((z+d)/512);j++)for(const b of waterBuckets.get(i+','+j)||[])if(b.bounds[0]<x+w&&b.bounds[2]>x&&b.bounds[1]<z+d&&b.bounds[3]>z)set.add(b);return [...set];}
function dryEdgePieces(q){const a=q[0],b=q[1],dx=b[0]-a[0],dz=b[1]-a[1],bands=waterBandsAt(Math.min(a[0],b[0])-.01,Math.min(a[1],b[1])-.01,Math.abs(dx)+.02,Math.abs(dz)+.02),polys=bands.map(b=>RailShape.polygon(b,0)),cuts=[0,1];
 for(const p of polys)for(let i=0;i<p.length;i++){const c=p[i],e=p[(i+1)%p.length],ex=e[0]-c[0],ez=e[1]-c[1],det=dx*ez-dz*ex;if(Math.abs(det)<1e-9)continue;const xx=c[0]-a[0],zz=c[1]-a[1],t=(xx*ez-zz*ex)/det,u=(xx*dz-zz*dx)/det;if(t>0&&t<1&&u>=0&&u<=1)cuts.push(t);}
 cuts.sort((a,b)=>a-b);const out=[];for(let i=1;i<cuts.length;i++){const lo=cuts[i-1],hi=cuts[i],mid=(lo+hi)/2;if(hi-lo<1e-8||polys.some(p=>RailShape.contains(p,a[0]+dx*mid,a[1]+dz*mid)))continue;out.push([[a[0]+dx*lo,a[1]+dz*lo],[a[0]+dx*hi,a[1]+dz*hi]]);}return out;
}
const tiers=[[500,10,256],[2000,20,512],[5000,32,1024],[10000,64,2048],[20000,96,4096],[40000,128,4096],[180000,512,16384]],tiles=[];
function tier(d){return tiers.find(t=>d<t[0])||tiers.at(-1)}
function partition(x,z,w){const near=Math.hypot(Math.max(0,Math.abs(x+w/2)-w/2),Math.max(0,Math.abs(z+w/2)-w/2));if(near>G.radiusM)return;const t=tier(near);if(w>t[2]){const h=w/2;partition(x,z,h);partition(x+h,z,h);partition(x,z+h,h);partition(x+h,z+h,h);}else tiles.push({id:'t'+tiles.length,x,z,w,step:t[1],backdrop:false});}
partition(-32768,-32768,65536);
class Mesh {
 constructor(x=0,z=0){this.x=x;this.z=z;this.p=[];this.n=[];this.c=[];this.i=[];}
 top(poly,y,col){if(poly.length<3)return;const off=this.p.length/3;for(const p of poly){this.p.push(p[0]-this.x,y+A.curvature(p[0],p[1]),p[1]-this.z);this.n.push(0,1,0);this.c.push(...col.map(v=>Math.round(A.clamp(v)*255)));}for(let i=1;i<poly.length-1;i++)this.i.push(off,off+i,off+i+1);}
 quad(q,col,normal){const off=this.p.length/3;for(const [i,p] of q.entries()){this.p.push(p[0]-this.x,p[1]+A.curvature(p[0],p[2]),p[2]-this.z);this.n.push(...normal);this.c.push(...(Array.isArray(col[0])?col[i]:col).map(v=>Math.round(A.clamp(v)*255)));}this.i.push(off,off+1,off+2,off,off+2,off+3);}
 box(x,y,z,w,h,d,col){const a=x-w/2,b=x+w/2,c=z-d/2,e=z+d/2,t=y+h;this.quad([[a,t,c],[a,t,e],[b,t,e],[b,t,c]],col,[0,1,0]);this.quad([[a,y,e],[b,y,e],[b,t,e],[a,t,e]],col,[0,0,1]);this.quad([[b,y,c],[a,y,c],[a,t,c],[b,t,c]],col,[0,0,-1]);this.quad([[a,y,c],[a,y,e],[a,t,e],[a,t,c]],col,[-1,0,0]);this.quad([[b,y,e],[b,y,c],[b,t,c],[b,t,e]],col,[1,0,0]);}
 slab(x,y,z,w,h,d,top,side,sides=true,options={}){
  const a=x-w/2,b=x+w/2,c=z-d/2,e=z+d/2,t=y+h;
  if(options.railCutouts?.length){const pieces=RailShape.subtract(options.railCutouts,a,c,w,d),area=pieces.reduce((sum,p)=>sum+Math.abs(p.reduce((v,q,i)=>{const r=p[(i+1)%p.length];return v+q[0]*r[1]-q[1]*r[0];},0))/2,0);
   if(options.tree&&area<w*d-.001)return;
   for(const poly of pieces){this.top(poly,t,top);
    if(sides)for(let i=0;i<poly.length;i++){const p=poly[i],q=poly[(i+1)%poly.length],dx=q[0]-p[0],dz=q[1]-p[1],len=Math.hypot(dx,dz);if(len<1e-6)continue;this.quad([[p[0],y,p[1]],[q[0],y,q[1]],[q[0],t,q[1]],[p[0],t,p[1]]],side,[-dz/len,0,dx/len]);}
   }return;
  }
  this.quad([[a,t,c],[a,t,e],[b,t,e],[b,t,c]],top,[0,1,0]);
  if(!sides)return;
  const faces=[[[a,e],[b,e],[0,0,1],.94],[[b,c],[a,c],[0,0,-1],.82],[[a,c],[a,e],[-1,0,0],.83],[[b,e],[b,c],[1,0,0],.94]];
  for(let f=0;f<4;f++){const [p,q,n,shade]=faces[f],bottom=Math.max(y,options.bottoms?.[f]??y);if(bottom>=t-.05)continue;
   const vertices=[[p[0],bottom,p[1]],[q[0],bottom,q[1]],[q[0],t,q[1]],[p[0],t,p[1]]];
   const shades=vertices.map(([xx,yy,zz])=>{const stain=A.noise(xx/37+yy/23+31,zz/41+yy/29+17),age=A.noise(xx/13+9,zz/17+yy/11),up=A.clamp((yy-y)/(h||1));return side.map((v,k)=>{
    const material=options.paint?A.mix(A.mix(v,A.colors.basalt[k],(1-up)*.16),A.colors.silverWall[k],up*.13):v;
    return material*shade*(options.paint?.84+stain*.22+age*.09:1);});});
   this.quad(vertices,shades,n);
  }
 }
 beam(a,b,w,col){
  const d=b.map((v,i)=>v-a[i]),len=Math.hypot(...d);if(len<.01)return;const f=d.map(v=>v/len),u=Math.hypot(f[0],f[2])<.001?[1,0,0]:[-f[2],0,f[0]],ul=Math.hypot(...u);for(let i=0;i<3;i++)u[i]/=ul;
  const v=[f[1]*u[2]-f[2]*u[1],f[2]*u[0]-f[0]*u[2],f[0]*u[1]-f[1]*u[0]],corner=(p,x,y)=>p.map((q,k)=>q+(u[k]*x+v[k]*y)*w/2);
  const aa=[corner(a,-1,-1),corner(a,1,-1),corner(a,1,1),corner(a,-1,1)],bb=[corner(b,-1,-1),corner(b,1,-1),corner(b,1,1),corner(b,-1,1)];
  for(let i=0;i<4;i++){const j=(i+1)%4,n=i===0?v.map(q=>-q):i===1?u:i===2?v:u.map(q=>-q);this.quad([aa[i],aa[j],bb[j],bb[i]],col,n);}this.quad(aa.slice().reverse(),col,f.map(q=>-q));this.quad(bb,col,f);
 }
 write(name){const nv=this.p.length/3,ni=this.i.length,b=Buffer.alloc(16+nv*18+ni*4);b.write('AVX1');b.writeUInt32LE(nv,4);b.writeUInt32LE(ni,8);let o=16;for(const v of this.p){b.writeFloatLE(v,o);o+=4;}for(const v of this.n)b.writeInt8(Math.round(A.clamp(v,-1,1)*127),o++);for(const v of this.c)b.writeUInt8(v,o++);for(const v of this.i){b.writeUInt32LE(v,o);o+=4;}const cliffTile=tiles.find(t=>name.startsWith(t.id+'-'));if(cliffTile)require('./atheria-cliff-finish.cjs').transform(b,cliffTile,Number(name.match(/-(\d+)\.bin$/)[1]));fs.writeFileSync(path.join(out,name),b);return{file:name,vertices:nv,triangles:ni/3,bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')};}
}
if(process.argv.includes('--transition-only')){
 const manifest=JSON.parse(fs.readFileSync(path.join(out,'manifest.json')));
 manifest.eyrieDetail=require('./atheria-eyrie-detail.cjs')({root,out,Mesh,model,A,site,tiles,aggregate});
 manifest.eyrieTransition=require('./atheria-eyrie-transition.cjs').build({root,out,Mesh,model,A,site,tiles,aggregate});
 for(const [key,input]of Object.entries(inputSnapshot))if(sha(input.file)!==input.sha256)throw Error('Input changed during transition rebuild: '+key);
 for(const file of ['atheria-eyrie-detail.cjs','atheria-eyrie-transition.cjs'])manifest.sourceHashes[file]=sha(path.join(__dirname,file));
 manifest.sourceHashes.generator=sha(__filename);manifest.buildId=new Date().toISOString();
 fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest));fs.writeFileSync(path.join(out,'manifest.js'),'window.ATHERIA_REGION_MANIFEST='+JSON.stringify(manifest)+';');
require('./build-atheria-cliff-look.cjs').build(root,out);
 console.log(JSON.stringify({transitionOnly:true,plantingTiles:manifest.eyrieTransition.plantingTiles,complete:true}));return;
}
const woodland=require('./atheria-woodland.cjs')({A,model,out,bandsAt:(x,z,s)=>[...transport.bandsAt(x,z,s),...waterBandsAt(x,z,s)]});
const refinement=refineMode?require('./atheria-building-refinement.cjs')({A,model,tiles,baseline:refineBaseline,out,life}):null;
if(refinement&&process.argv.includes('--refinement-plan-only')){fs.writeFileSync(path.join(out,'building-refinement-plan.json'),JSON.stringify({report:refinement.report,blocks:refinement.blocks,houses:refinement.houses,infill:refinement.infill},null,2));return;}
function accumulateDecor(map,d,weight){
 if(!d||!['building','crop','orchard','grove','court','garden'].includes(d.kind))return;
 const key=d.kind+':'+(d.kind==='building'?d.id:['crop','orchard','court','garden'].includes(d.kind)?d.id:'canopy');
 let q=map.get(key);if(!q){q={id:d.id,kind:d.kind,form:d.form||0,weight:0,color:[0,0,0],facade:[0,0,0],top:0,relief:0};map.set(key,q);}
 if(d.canopyMask){q.canopyMask=true;q.canopyFraction=(q.canopyFraction||0)+(d.canopyFraction||0)*weight;q.canopyGroup=d.canopyGroup;q.canopyFamily=d.canopyFamily;}
 q.weight+=weight;for(let k=0;k<3;k++){q.color[k]+=d.color[k]*weight;q.facade[k]+=(d.facade||d.color)[k]*weight;}q.top+=(d.top||0)*weight;q.relief+=(d.relief||0)*weight;
}
function chooseDecor(map,total){
 const all=[...map.values()],buildings=all.filter(d=>d.kind==='building'&&d.weight/total>=.20),q=(buildings.length?buildings:all).sort((a,b)=>b.weight-a.weight)[0];
 if(!q)return null;return{id:q.id,kind:q.kind,form:q.form,coverage:q.weight/total,color:q.color.map(v=>v/q.weight),facade:q.facade.map(v=>v/q.weight),top:q.top/q.weight,relief:q.relief/q.weight,...(q.canopyMask?{canopyMask:true,canopyFraction:q.canopyFraction/q.weight,canopyGroup:q.canopyGroup,canopyFamily:q.canopyFamily}:{})};
}
function aggregate(x,z,s,backdrop){
 let h=0,color=[0,0,0],n=0;const count=s>64?4:3,objects=new Map();
 for(let j=0;j<count;j++)for(let i=0;i<count;i++){
  const xx=x+(i+.5)/count*s,zz=z+(j+.5)/count*s,p=model.surface(xx,zz,s);
  h+=backdrop?native(xx,zz)-720:p.height;for(let k=0;k<3;k++)color[k]+=p.color[k];if(!backdrop)accumulateDecor(objects,p.decor,1);n++;
 }
 let ground=h/n;const stream=model.waterAt(x+s/2,z+s/2);
 if(stream&&stream.bank<s*.65){const t=A.smooth(-s*.25,s*.65,stream.bank);ground=Math.min(ground,A.mix(stream.level-stream.depth,ground,t));}
 const paint=transport.paintCell(x,z,s),painted=color.map((v,k)=>paint.color?A.mix(v/n,paint.color[k],paint.strength):v/n);
 return{h:Math.round(ground/2)*2,g:ground,roof:0,c:painted,facade:A.colors.stone,decor:chooseDecor(objects,n)};
}
// One world-space crown list owns the global budget; LODs never resample it.
const roofCandidates=[],roofSeen=new Set(),roofTrees=[],roofVoxelCap=200;
for(const c of refinement?[]:model.landscape.compounds){
 const density=A.smooth(.32,.78,A.noise(c.x/720+137,c.z/830+193));if(density<.025)continue;
 for(const [mi,m] of c.masses.entries()){
  const xx=c.x+m.x*c.cs-m.z*c.sn,zz=c.z+m.x*c.sn+m.z*c.cs,t=tiles.find(t=>xx>=t.x&&xx<t.x+t.w&&zz>=t.z&&zz<t.z+t.w);if(!t||model.landscape.protectedAt(xx,zz))continue;
  const cell=t.w/Math.ceil(t.w/t.step),ix=Math.floor((xx-t.x)/cell),iz=Math.floor((zz-t.z)/cell),x=t.x+(ix+.5)*cell,z=t.z+(iz+.5)*cell,key=t.id+':'+ix+','+iz;if(roofSeen.has(key))continue;roofSeen.add(key);
  const a=aggregate(x-cell/2,z-cell/2,cell,false),d=a.decor,seed=A.hash(Math.round(x),Math.round(z),3217);if(d?.kind!=='building'||d.id!==c.id||d.coverage<.75)continue;
  const size=cell*(.20+(seed%100)/100*.15),half=size/2;
  if([[-half,-half],[half,-half],[-half,half],[half,half],[0,0]].some(([dx,dz])=>{const b=model.urbanAt(x+dx,z+dz);return !b||b.id!==c.id||Math.abs(b.top-d.top)>2.1;}))continue;
  const q=(A.hash(Math.round(x),Math.round(z),3221)+1)/4294967297,colour=(seed>>>9)%100;
  roofCandidates.push({id:'roof-'+key,owner:c.id,tile:t.id,x,z,w:size,d:size*(.82+(seed>>>17)%30/100),h:size*(.6+(seed>>>21)%40/100),color:A.colors[colour<85?['appleLeaf','pearLeaf','plumLeaf'][(seed>>>12)%3]:colour<92?'cropHoney':colour<97?'copperLight':'plumCloth'],rank:-Math.log(q)/Math.max(.02,density*density),density,cellM:cell});
 }
}
const perHouse=new Map();for(const candidate of roofCandidates.sort((a,b)=>a.rank-b.rank||a.id.localeCompare(b.id))){if(roofTrees.length>=180)break;const count=perHouse.get(candidate.owner)||0;if(count>=2)continue;perHouse.set(candidate.owner,count+1);roofTrees.push(candidate);}
if(refinement)for(const tree of refinement.retainedRoof){roofTrees.push(tree);perHouse.set(tree.owner,(perHouse.get(tree.owner)||0)+1);}
if(roofTrees.length>roofVoxelCap)throw Error('Global roof crown budget exceeded');
const roofByTile=new Map();for(const tree of roofTrees){if(!roofByTile.has(tree.tile))roofByTile.set(tree.tile,[]);roofByTile.get(tree.tile).push(tree);}const roofEmissions=[],decorCounts={court:0,garden:0};
for(let ti=0;ti<tiles.length;ti++){
 const t=tiles[ti],n0=Math.ceil(t.w/t.step);t.levels=[];
 if(refinement&&!refinement.affected.has(t.id)){t.levels=accepted.tiles.find(p=>p.id===t.id).levels;continue;}
 if(onlyTile&&t.id!==onlyTile){const old=previousManifest.tiles.find(p=>p.id===t.id);if(!old||old.x!==t.x||old.z!==t.z||old.w!==t.w||old.step!==t.step)throw Error('Tile layout changed; full rebuild required');t.levels=old.levels;continue;}
 const fineStep=t.w/n0,fineCache=new Map(),fineAt=(i,j)=>{const key=i+','+j;if(!fineCache.has(key))fineCache.set(key,aggregate(t.x+i*fineStep,t.z+j*fineStep,fineStep,t.backdrop));return fineCache.get(key);};
 woodland.prepare(t,n0,fineAt);
 if(refinement)refinement.clearSources(t,n0,fineAt);
 function reduced(i,j,n){
  if(n===n0)return fineAt(i,j);
  const x0=i*n0/n,x1=(i+1)*n0/n,z0=j*n0/n,z1=(j+1)*n0/n;
  let area=0,h=0,g=0,roof=0,c=[0,0,0],facade=[0,0,0];const objects=new Map();
  for(let z=Math.floor(z0);z<Math.ceil(z1);z++)for(let x=Math.floor(x0);x<Math.ceil(x1);x++){
   const weight=(Math.min(x1,x+1)-Math.max(x0,x))*(Math.min(z1,z+1)-Math.max(z0,z)),a=fineAt(x,z);
   area+=weight;h+=a.h*weight;g+=a.g*weight;roof+=a.roof*weight;accumulateDecor(objects,a.decor,weight*(a.decor?.coverage||0));
   for(let k=0;k<3;k++){c[k]+=Math.round(a.c[k]*255)/255*weight;facade[k]+=a.facade[k]*a.roof*weight;}
  }
  return{h:Math.round(h/area/2)*2,g:g/area,roof:roof/area,c:c.map(v=>v/area),facade:roof>0?facade.map(v=>v/roof):A.colors.stone,decor:chooseDecor(objects,area)};
 }
 for(let lod=0;lod<4;lod++){
  const n=Math.max(3,Math.ceil(n0/2**lod)),s=t.w/n,values=[];for(let j=-1;j<=n;j++)for(let i=-1;i<=n;i++)values.push(reduced(i,j,n));
  const railGround={},roofCells=new Map();
  for(const tree of roofByTile.get(t.id)||[]){const key=Math.floor((tree.x-t.x)/s)+','+Math.floor((tree.z-t.z)/s);if(!roofCells.has(key))roofCells.set(key,[]);roofCells.get(key).push(tree);}
  const at=(i,j)=>values[(j+1)*(n+2)+i+1],mesh=new Mesh(t.x,t.z),merged=new Uint8Array(n*n),same=(a,b)=>a.h===b.h&&a.c.every((v,i)=>Math.round(v*255)===Math.round(b.c[i]*255));
  function wall(q,top,bot,norm,x,z,surface){if(top<=bot+.1)return;
   const dry=dryEdgePieces(q);
   const building=surface.roof>.18&&top>surface.g+2,ground=building?Math.max(bot,Math.min(top,surface.g)):top,
    emit=(a,b,col)=>{if(b>a+.05)for(const p of dry)mesh.quad([[p[0][0],a,p[0][1]],[p[1][0],a,p[1][1]],[p[1][0],b,p[1][1]],[p[0][0],b,p[0][1]]],col,norm);};
   const segments=Math.min(6,Math.max(1,Math.ceil((ground-bot)/18)));for(let k=0;k<segments;k++){const a=A.mix(bot,ground,k/segments),b=A.mix(bot,ground,(k+1)/segments),v=.88+.14*A.noise(x/220,(a+z/20)/60),col=A.colors.stone.map((c,i)=>A.mix(c,A.colors.basalt[i],.13+.14*Math.sin(a*.12+x*.001))*v);emit(a,b,col);}
   // Visible building sides retain timber/plaster and a broad roof edge. Rock only
   // continues below the real bearing surface, including the hidden tile skirt.
   if(building){const cap=Math.min(1.6,(top-ground)*.22);emit(ground,top-cap,surface.facade);emit(top-cap,top,surface.c);}
  }
  for(let j=0;j<n;j++)for(let i=0;i<n;i++){const x=t.x+i*s,z=t.z+j*s,a=at(i,j),h=a.h;if(Math.hypot(x+s/2,z+s/2)>G.radiusM+s)continue;if(!merged[j*n+i]){let end=i+1;while(end<n&&end<i+4&&same(a,at(end,j))){merged[j*n+end]=1;end++;}const right=t.x+end*s,waterCuts=model.landscape.protectedAt(x+s/2,z+s/2)?[]:waterBandsAt(x,z,right-x,s),polys=waterCuts.length?RailShape.subtract(waterCuts,x,z,right-x,s,0):null;
    if(!polys)mesh.quad([[x,h,z],[x,h,z+s],[right,h,z+s],[right,h,z]],a.c,[0,1,0]);
    else for(const poly of polys){mesh.top(poly,h,a.c);
     for(let k=0;k<poly.length;k++){const p=poly[k],q=poly[(k+1)%poly.length],xx=(p[0]+q[0])/2,zz=(p[1]+q[1])/2,near=waterCuts.filter(b=>RailShape.contains(RailShape.polygon({...b,width:b.width+.02},s),xx,zz));if(!near.length)continue;const bottom=Math.min(h,...near.map(b=>b.level-.4)),dx=q[0]-p[0],dz=q[1]-p[1],len=Math.hypot(dx,dz);if(bottom>=h-.05||len<1e-6)continue;mesh.quad([[p[0],bottom,p[1]],[q[0],bottom,q[1]],[q[0],h,q[1]],[p[0],h,p[1]]],a.c.map((v,k)=>A.mix(v,A.colors.wetMeadow[k],.25)),[-dz/len,0,dx/len]);}
    }
   }
   const d=a.decor;if(lod===0&&d&&d.kind in decorCounts)decorCounts[d.kind]++;
   if(d){
    const building=d.kind==='building',court=d.kind==='court',garden=d.kind==='garden',tree=d.kind==='orchard'||d.kind==='grove',threshold=building?.24:tree?.24:court||garden?.28:.34;
    if(d.coverage>=threshold&&s<=(court?64:192)){
     if(building&&refinement)refinement.countOrdinary(lod);
     const gap=building?Math.min(1.3,s*.025):tree?s*.14:s*.035,
      sx=x+s/2,sz=z+s/2,relief=building?Math.max(3,Math.min(50,d.top-a.g)):tree?d.relief*(.78+.22*d.coverage):court?s*d.relief:d.relief,
      variation=.95+(A.hash(Math.floor(sx/10),Math.floor(sz/10),1777)%11)*.01,
      top=d.color.map(v=>v*variation),side=building?d.facade:tree?d.facade:d.color.map((v,k)=>A.mix(v,A.colors.tilledEarth[k],.42));
     if(building)for(const tree of roofCells.get(i+','+j)||[]){if(tree.owner!==d.id)continue;
      const inset=Math.min(1.3,s*.025),inside=tree.x-tree.w/2>x+inset&&tree.x+tree.w/2<x+s-inset&&tree.z-tree.d/2>z+inset&&tree.z+tree.d/2<z+s-inset;if(!inside)continue;
      const y=h+.04+relief;if(s<=tree.cellM*2.05){mesh.slab(tree.x,y,tree.z,tree.w,tree.h,tree.d,tree.color,tree.color.map(v=>v*.72),true);roofEmissions.push({id:tree.id,tile:t.id,lod,y,roofTop:y,world:[tree.x,tree.z],voxelCount:1});}
      else {const amount=Math.min(.09,tree.w*tree.d/(s*s));for(let k=0;k<3;k++)top[k]=A.mix(top[k],tree.color[k],amount);}
     }
     // Thin crop edges below the regional pixel scale need only the raised top;
     // nearby plots, tree crowns and buildings retain all four shaded sides.
     const edgeGap=(xx,zz,other)=>{
      const sameObject=other?.decor?.kind===d.kind&&other.decor.id===d.id&&other.decor.coverage>=threshold,
       localCluster=building||Math.floor(sx/(s*2))===Math.floor((2*xx-sx)/(s*2))&&Math.floor(sz/(s*2))===Math.floor((2*zz-sz)/(s*2)),
       noise=A.noise(xx/73+23,zz/81+31),join=sameObject&&!tree&&localCluster&&noise>.43;
      return join?0:tree?s*(.08+.08*noise):building?gap*(.35+noise):s*(.012+.038*noise);
     };
     const gapNoise=A.noise(sx/51+19,sz/53+31),plantGap=s*(.04+.06*gapNoise)/2;
     const left=court||garden?plantGap:edgeGap(x,sz,at(i-1,j)),right=court||garden?plantGap:edgeGap(x+s,sz,at(i+1,j)),back=court||garden?plantGap:edgeGap(sx,z,at(i,j-1)),front=court||garden?plantGap:edgeGap(sx,z+s,at(i,j+1)),
      bottomFor=(other,g)=>g===0&&other.decor?.kind===d.kind&&other.decor.id===d.id?other.h+.04+(building?Math.max(3,Math.min(50,other.decor.top-other.g)):other.decor.relief):h+.04;
      const crownX=tree?(A.hash(Math.floor(sx),Math.floor(sz),2011)%100/100-.5)*s*.23:0,crownZ=tree?(A.hash(Math.floor(sx),Math.floor(sz),2017)%100/100-.5)*s*.23:0,crownScale=tree?([.86,.62,.77,.79][d.form%4]||.78)+(A.hash(Math.floor(sx),Math.floor(sz),2027)%100/100-.5)*.10:1;
     if(tree&&d.canopyMask)woodland.emit({mesh,t,lod,x,z,s,h,d,relief});
     else mesh.slab(sx+(left-right)*.5+crownX,h+.04,sz+(back-front)*.5+crownZ,(s-left-right)*crownScale,relief,(s-back-front)*crownScale,top,side,!(d.kind==='crop'&&s>32),{paint:building,railCutouts:!building?[...(s<=32?transport.bandsAt(x-s/2,z-s/2,s*2):[]),...waterBandsAt(x-s/2,z-s/2,s*2)]:null,tree,bottoms:court||garden?undefined:[bottomFor(at(i,j+1),front),bottomFor(at(i,j-1),back),bottomFor(at(i-1,j),left),bottomFor(at(i+1,j),right)]});
    }else{
     // Subpixel roofs and crops contribute colour, never a raised whole cell.
     const c=a.c.map((v,k)=>A.mix(v,d.color[k],d.coverage));
     const waterCuts=waterBandsAt(x,z,s),polys=waterCuts.length?RailShape.subtract(waterCuts,x,z,s,s,0):[[[x,z],[x,z+s],[x+s,z+s],[x+s,z]]];for(const p of polys)mesh.top(p,h+.025,c);
    }
   }
   if(!model.landscape.protectedAt(x+s/2,z+s/2)){
    const cellBands=transport.bandsAt(x,z,s),parts=s<=32?RailShape.pieces(cellBands,x,z,s,h):[];
    // Subpixel tracks disappear into the field; never paint a whole LOD cell.
    if(parts.length){
     railGround[j*n+i]=h;
     for(const part of parts){const top=h+part.relief,p=part.p,cx=p.reduce((v,q)=>v+q[0],0)/p.length,cz=p.reduce((v,q)=>v+q[1],0)/p.length,under=model.landscape.surfaceAt(cx,cz,model.landUse(cx,cz),s,true),field=d&&['crop','garden','court'].includes(d.kind)?d.color:under&&['crop','garden','court','margin','path','groundTint'].includes(under.kind)?under.color:a.c,railColour=field.map((v,k)=>A.mix(v,A.colors.tilledEarth[k],.06));mesh.quad(p.map(q=>[q[0],top,q[1]]),railColour,[0,1,0]);
      if(s<=32)for(let k=0;k<4;k++){const a=p[k],b=p[(k+1)%4],dx=b[0]-a[0],dz=b[1]-a[1],len=Math.hypot(dx,dz);if(len<1e-5)continue;const xx=(a[0]+b[0])/2-dz/len*.0002,zz=(a[1]+b[1])/2+dx/len*.0002,neighbour=parts.reduce((v,q)=>RailShape.contains(q.p,xx,zz)?Math.max(v,q.relief):v,0),bottom=part.bridge?Math.max(top-1,h+neighbour):h+neighbour;if(bottom>=top-1e-5)continue;mesh.quad([[a[0],bottom,a[1]],[b[0],bottom,b[1]],[b[0],top,b[1]],[a[0],top,a[1]]],railColour,[-dz/len,0,dx/len]);}
     }
    }
   }
   wall([[x,z],[x,z+s]],h,i===0?Math.min(at(i-1,j).h,h-220):at(i-1,j).h,[-1,0,0],x,z,a);
   wall([[x+s,z+s],[x+s,z]],h,i===n-1?Math.min(at(i+1,j).h,h-220):at(i+1,j).h,[1,0,0],x,z,a);
   wall([[x+s,z],[x,z]],h,j===0?Math.min(at(i,j-1).h,h-220):at(i,j-1).h,[0,0,-1],x,z,a);
   wall([[x,z+s],[x+s,z+s]],h,j===n-1?Math.min(at(i,j+1).h,h-220):at(i,j+1).h,[0,0,1],x,z,a);
  }
   if(refinement)refinement.emit(mesh,t,lod,(x,z)=>at(Math.max(-1,Math.min(n,Math.floor((x-t.x)/s))),Math.max(-1,Math.min(n,Math.floor((z-t.z)/s)))).h);
   for(const b of life.boxes){if(b.x<t.x||b.x>=t.x+t.w||b.z<t.z||b.z>=t.z+t.w||Math.hypot(b.x,b.z)>G.radiusM)continue;
   if(s>128)continue;mesh.slab(b.x,b.y+.2,b.z,b.w,b.h,b.d,b.color,b.facade,true,{paint:true});
  }
  // Static transit belongs to each existing chunk. Clip beams at chunk borders.
  if(lod<2){
   for(const b of transport.beams){let lo=0,hi=1;for(const k of[0,2]){const d=b.b[k]-b.a[k],min=k===0?t.x:t.z,max=min+t.w;if(Math.abs(d)<1e-8){if(b.a[k]<min||b.a[k]>=max)hi=-1;}else{const u=(min-b.a[k])/d,v=(max-b.a[k])/d;lo=Math.max(lo,Math.min(u,v));hi=Math.min(hi,Math.max(u,v));}}if(hi>lo)mesh.beam(b.a.map((v,k)=>A.mix(v,b.b[k],lo)),b.a.map((v,k)=>A.mix(v,b.b[k],hi)),b.width,b.color);}
   for(const b of transport.blocks)if(b.x>=t.x&&b.x<t.x+t.w&&b.z>=t.z&&b.z<t.z+t.w)mesh.box(b.x,b.y,b.z,b.w,b.h,b.d,b.color);
   for(const p of transport.pads)if(p.x>=t.x&&p.x<t.x+t.w&&p.z>=t.z&&p.z<t.z+t.w){const c=A.colors[p.material],h=p.y-p.base;
    if(p.shape===0)mesh.box(p.x,p.base,p.z,p.w,h,p.d,c);else{mesh.box(p.x,p.base,p.z,p.w*.64,h,p.d,c);mesh.box(p.x,p.base,p.z,p.w,h,p.d*.57,c);}
    mesh.box(p.x+p.w*.4,p.y,p.z,p.w*.20,.65,p.d*.32,A.colors.heartwood);
   }
  }
  t.levels.push({...mesh.write(t.id+'-'+lod+'.bin'),cellM:s,railGridN:n,railGround});
 }
 if(ti%40===0)console.log('Terrain chunks '+ti+'/'+tiles.length);
}
if(refinement){
 const manifest=JSON.parse(JSON.stringify(accepted));manifest.buildId=new Date().toISOString();manifest.tiles=tiles;
 const neighbourhoodMesh=refinement.emitNeighbourhood(new Mesh());
 manifest.buildingRefinement={...refinement.finish(),neighbourhoodMesh};manifest.sourceHashes.generator=sha(__filename);manifest.sourceHashes['atheria-building-refinement.cjs']=sha(path.join(__dirname,'atheria-building-refinement.cjs'));
 const trees=[...roofTrees,...refinement.fixedTrees],emissions=[...refinement.originalRoof.emissions.filter(e=>!refinement.affected.has(e.tile)),...roofEmissions,...refinement.fixedTreeEmissions];
 manifest.roofTrees={...accepted.roofTrees,worldVoxelCount:trees.length,households:new Set(trees.map(t=>t.owner)).size,emittedByLod:[0,1,2,3].map(l=>emissions.filter(e=>e.lod===l).length)};
 fs.writeFileSync(path.join(out,'roof-trees.json'),JSON.stringify({voxelCap:roofVoxelCap,trees,emissions}));
 for(const [key,input]of Object.entries(inputSnapshot))if(sha(input.file)!==input.sha256)throw Error('Input changed during building refinement: '+key);
 fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest));fs.writeFileSync(path.join(out,'manifest.js'),'window.ATHERIA_REGION_MANIFEST='+JSON.stringify(manifest)+';');
require('./build-atheria-cliff-look.cjs').build(root,out);
 fs.writeFileSync(path.join(out,'generation.json'),JSON.stringify({coverage,tiles:tiles.length,refinedTiles:refinement.affected.size,bytes:tiles.reduce((n,t)=>n+t.levels.reduce((a,l)=>a+l.bytes,0),0),triangles:tiles.reduce((n,t)=>n+t.levels[0].triangles,0),buildingRefinement:manifest.buildingRefinement},null,2));
 console.log(JSON.stringify({out,buildingRefinement:manifest.buildingRefinement,complete:true}));return;
}
const water=new Mesh(),waterColor=A.colors.water;
for(const c of model.channels)for(let i=0;i<c.points.length-1;i++){const a=c.points[i],b=c.points[i+1],dx=b[0]-a[0],dz=b[1]-a[1],len=Math.hypot(dx,dz)||1,nx=-dz/len,nz=dx/len;if(Math.min(Math.hypot(a[0],a[1]),Math.hypot(b[0],b[1]))>G.radiusM+len+Math.max(a[3],b[3]))continue;water.quad([[a[0]+nx*a[3]/2,a[2]+.25,a[1]+nz*a[3]/2],[b[0]+nx*b[3]/2,b[2]+.25,b[1]+nz*b[3]/2],[b[0]-nx*b[3]/2,b[2]+.25,b[1]-nz*b[3]/2],[a[0]-nx*a[3]/2,a[2]+.25,a[1]-nz*a[3]/2]],waterColor,[0,1,0]);}
for(const l of model.lakes){for(let i=0;i<48;i++){const a=i/48*Math.PI*2,b=(i+1)/48*Math.PI*2,point=t=>[l.x+Math.cos(t)*l.width/2/(1+.06*Math.sin(t*5)),l.level+.25,l.z+Math.sin(t)*l.depth/2/(1+.06*Math.sin(t*5))];water.quad([[l.x,l.level+.25,l.z],point(b),point(a),[l.x,l.level+.25,l.z]],waterColor,[0,1,0]);}}
// Foam and plunge pools share the existing water batch.
for(const f of model.falls){const p=f.to,w=p[3],r=Math.max(9,w*.95),y=p[2]+.30;
 water.quad([[p[0]-r,y,p[1]-r*.6],[p[0]-r,y,p[1]+r*.6],[p[0]+r,y,p[1]+r*.6],[p[0]+r,y,p[1]-r*.6]],A.colors.water.map((c,k)=>A.mix(c,A.colors.linen[k],.32)),[0,1,0]);
}
const special=[];
// Coarse copy derived from accepted architecture triangles; the originals are read-only.
const eyrieManifest=JSON.parse(fs.readFileSync(path.join(root,'eyrie-assets/manifest.json'))),cells=new Map(),sourceParts=[];
for(const p of eyrieManifest.parts){if(p.prototype||p.parent||!['walls','roof','floor','structure'].includes(p.layer)||p.id==='rock-root')continue;const file=path.join(root,'eyrie-assets',p.id+'.bin');if(!fs.existsSync(file))continue;const b=fs.readFileSync(file),nv=b.readUInt32LE(0),ni=b.readUInt32LE(4),pos=16,norm=pos+nv*12,col=norm+nv*3,idx=col+nv*12+nv*8,angle=p.rotation||0,c=Math.cos(angle),s=Math.sin(angle),off=p.position||[0,0,0];let included=false;
 for(let i=0;i<ni;i+=3){const ids=[0,1,2].map(k=>b.readUInt32LE(idx+(i+k)*4)),points=ids.map(id=>{const x=b.readFloatLE(pos+id*12),y=b.readFloatLE(pos+id*12+4),z=b.readFloatLE(pos+id*12+8);return[off[0]+x*c+z*s,off[1]+y,off[2]-x*s+z*c]}),v=points.reduce((a,p)=>a.map((n,j)=>n+p[j]/3),[0,0,0]);if(Math.hypot(v[0],v[2])>105||v[1]<-126)continue;
  const key=[Math.floor(v[0]/10),Math.floor(v[1]/5),Math.floor(v[2]/10)].join(','),a=points[1].map((q,j)=>q-points[0][j]),d=points[2].map((q,j)=>q-points[0][j]),area=Math.hypot(a[1]*d[2]-a[2]*d[1],a[2]*d[0]-a[0]*d[2],a[0]*d[1]-a[1]*d[0])/2;if(area<1e-5)continue;if(!cells.has(key))cells.set(key,{area:0,c:[0,0,0]});const cell=cells.get(key);cell.area+=area;for(let j=0;j<3;j++)cell.c[j]+=ids.reduce((v,id)=>v+b.readFloatLE(col+id*12+j*4)/3,0)*area;included=true;
 }if(included)sourceParts.push({id:p.id,sha256:sha(file)});
}
const copy=new Mesh();for(const [key,v]of cells){if(v.area<4)continue;const [x,y,z]=key.split(',').map(Number);copy.box(x*10+5,y*5,z*10+5,10,5,10,v.c.map(n=>n/v.area));}special.push({id:'eyrie-copy',kind:'eyrie-copy',x:0,z:0,mesh:copy.write('eyrie-copy.bin'),sourceParts,cellM:[10,5,10]});
for(const f of transport.ports){const m=new Mesh(f.x,f.z);for(const b of f.blocks)m.slab(b.x,b.y,b.z,b.w,b.h,b.d,b.color,b.color,true,{paint:true});special.push({...f,blocks:undefined,kind:f.id==='harbour'?'harbour':'community',mesh:m.write(f.id+'.bin')});}
const overview={};for(let z=-G.radiusM;z<G.radiusM;z+=256)for(let x=-G.radiusM;x<G.radiusM;x+=256){if(Math.hypot(x,z)>G.radiusM)continue;const v=model.surface(x,z,256);overview[x+','+z]=[Math.round(v.height),...v.color.map(v=>Math.round(v*255))];}
const mapFeatures={type:'FeatureCollection',features:[...model.lakes.map(l=>({type:'Feature',id:l.id,geometry:{type:'Polygon',coordinates:[Array.from({length:33},(_,i)=>A.geo(l.x+Math.cos(i/32*2*Math.PI)*l.width/2,l.z+Math.sin(i/32*2*Math.PI)*l.depth/2))]},properties:{kind:'lake',waterLevelM:l.level+720,source:l.source}})),...G.cliffPaths().map((c,j)=>({type:'Feature',id:'atheria-cliff-'+j,geometry:{type:'LineString',coordinates:c.points.map(p=>A.geo(...p))},properties:{kind:'cliff',level:c.level,heightM:c.level===0?120:150,source:G.revision}}))]};
fs.writeFileSync(path.join(out,'map-features.json'),JSON.stringify(mapFeatures));fs.writeFileSync(path.join(out,'map-features.js'),'window.ATHERIA_MAP_FEATURES='+JSON.stringify(mapFeatures)+';');
const manifest={version:2,buildId:new Date().toISOString(),seed:20260909,scope:'Independent Atheria regional page; original Eyrie files unchanged',origin:{lon: A.origin[0],lat:A.origin[1],elevationM:720,axes:'+X east, +Z south, +Y up',planetRadiusM:A.R},radiusM:G.radiusM,backgroundRadiusM:G.radiusM,tiers:tiers.slice(0,6).map(t=>({untilM:t[0],cellM:t[1]})),palette:A.palette,coverage,tiles,water:water.write('water.bin'),communities:special,lakes:model.lakes,channels:model.channels.map(c=>({id:c.id,existing:c.existing,points:c.points,downstreamId:c.downstreamId})),eyrieProxy:{position:[0,0,0],sourceBuild:eyrieManifest.buildId,mode:'Area-weighted voxel copy of original architecture; original files unchanged',cellM:[10,5,10],sourceParts:sourceParts.length},sourceHashes:{atlas:sha(atlasPath),eyrie:sha(path.join(root,'eyrie-assets/manifest.json')),native:sha(nativePath)},views:{overview:{position:[9200,5800,10400],target:[-1000,160,-1500]},eyrie:{position:[-170,90,220],target:[0,-10,0]},shelves:{position:[4800,2100,4400],target:[-300,130,-900]},lakes:{position:[-6600,850,model.lakes[0].z+900],target:[-5700,model.lakes[0].level,model.lakes[0].z]},community:{position:[-1590,320,A.edge(-1400,1)+350],target:[-1400,175,A.edge(-1400,1)-70]},ishkar:{position:[26000,10500,35000],target:[18000,0,27000]},north:{position:[1000,2900,-8500],target:[0,20,1200]},wide:{position:[45000,62000,68000],target:[0,0,0]}}};
manifest.views.neighbourhood={position:[630,320,360],target:[80,10,-250]};
manifest.views.farmland={position:[3200,1700,7000],target:[1600,-100,4000]};
const terraceFocus=model.landscape.compounds.filter(c=>c.architecture==='compound'&&c.w>220).sort((a,b)=>Math.hypot(a.x,a.z)-Math.hypot(b.x,b.z))[0];
manifest.views.compounds={position:[terraceFocus.x+terraceFocus.w*1.25,terraceFocus.base+terraceFocus.w*.90,terraceFocus.z+terraceFocus.w*1.45],target:[terraceFocus.x,terraceFocus.base+18,terraceFocus.z]};
manifest.fieldRepresentation={voxelGapFraction:[0,.10],sharedEdgeNoise:true,raisedCropM:[.45,2.25],orchardCrownM:[5,13],materials:Object.keys(A.fieldPalette),dominant:'wheat',macroVariationM:[1450,2600],parcelM:[205,260],microVariationM:[37,125],layout:'directional rectangular holdings, contour strips and natural margins; variable shared gaps and locally joined crop voxels'};
manifest.lodAggregation='Area-weighted reduction of the same finest visible surface colours and heights within each chunk';
manifest.biomeRepresentation={kind:'continuous domain-warped moisture and warmth gradients',scalesM:[95,370,1300,3900],groundColorFade:true,canopyDensityFade:true,cropMarginFade:true,preserveVoxelGaps:true};
manifest.terrainProvinces=A.provinces.map(p=>({...p,source:'local geological and weathering interpretation within existing continent relief'}));manifest.urbanRepresentation={...model.landscape.stats,ordinaryRoofHeightM:[5,50],materialFamilies:['terracotta and ochre','slate and aged copper','pale wood and lime','dark heartwood','dyed cloth'],separateFacadeMaterials:true,dispersedConnectedCompounds:true,isolatedHouseScatter:true,groundSeparatedFromObjects:true};manifest.sourceHashes.model=sha(path.join(__dirname,'atheria-region-model.cjs'));manifest.sourceHashes.generator=sha(__filename);manifest.sourceHashes.landscape=sha(path.join(__dirname,'atheria-landscape.cjs'));
manifest.sourceHashes.publicGround=sha(path.join(__dirname,'atheria-public-ground.cjs'));
manifest.publicGround=model.landscape.stats.publicGround;
manifest.geography={revision:G.revision,clipping:'circle in world metres, all materials',centralDropM:420,wingTransitionM:[6000,14000],nativeSource:'frozen pre-reconstruction terrain; local deformation applied once'};
manifest.lifeBlocks={counts:life.counts,boxes:life.boxes.length,representation:life.representation};manifest.waterfalls=model.falls;
manifest.views.wide={position:[20500,36500,26500],target:[0,-30,-1500]};
manifest.views.overview={position:[12500,9800,15100],target:[0,60,-2800]};
manifest.views.ishkar={position:[6500,6000,-21000],target:[5000,-50,-12500]};
manifest.views.west={position:[-14700,3300,3900],target:[-9300,20,-2500]};
manifest.views.east={position:[15500,3800,5000],target:[9600,20,-2600]};
manifest.views.rear={position:[-2500,7400,-18000],target:[0,100,-5500]};
manifest.views.waterfalls={position:[-6000,950,900],target:[-5400,35,-450]};
const cart=life.objects.find(o=>o.kind==='rail-cart');if(cart)manifest.views.life={position:[cart.x+180,cart.y+170,cart.z+220],target:[cart.x,cart.y+5,cart.z]};
for(const file of ['atheria-geography.cjs','atheria-water.cjs','atheria-life-blocks.cjs','atheria-transport.cjs','atheria-ground-network.cjs','atheria-river-curves.cjs','atheria-rail-shape.cjs','atheria-terrace-water.cjs','atheria-upland.cjs','atheria-eyrie-detail.cjs','atheria-woodland.cjs','atheria-eyrie-transition.cjs'])manifest.sourceHashes[file]=sha(path.join(__dirname,file));
for(const file of ['atheria-river-seed.json','atheria-coarse-baseline.json','atheria-layout-seed.json'])manifest.sourceHashes[file]=sha(path.join(root,'data',file));
fs.writeFileSync(path.join(out,'life-blocks.json'),JSON.stringify(life));
fs.writeFileSync(path.join(out,'transport.json'),JSON.stringify(transport));
manifest.transport={version:1,file:'transport.json',stats:transport.stats,ports:transport.ports.map(p=>({id:p.id,heightM:p.height,regionalBerths:p.regionalBerths}))};
manifest.gardenInfill={flowerAreaTarget:.50,wheatAndGrassAreaTarget:.50,courtHeightCellFraction:[.03,.06],gapCellFraction:[.04,.10],palette:['bloomBlue','bloomPink','bloomOrange','bloomLilac','bloomCream'],finestCellCounts:decorCounts};
manifest.roofTrees={voxelCap:roofVoxelCap,worldVoxelCount:roofTrees.length,households:perHouse.size,noiseScaleM:[720,830],fixedWorldSeeds:true,emittedByLod:[0,1,2,3].map(l=>roofEmissions.filter(e=>e.lod===l).length),file:'roof-trees.json'};
const roofFocus=roofTrees.filter(t=>roofEmissions.some(e=>e.id===t.id&&e.lod===0)).sort((a,b)=>Math.hypot(a.x,a.z)-Math.hypot(b.x,b.z))[0];if(roofFocus){const e=roofEmissions.find(e=>e.id===roofFocus.id&&e.lod===0);manifest.views.roofgarden={position:[roofFocus.x+115,e.y+100,roofFocus.z+145],target:[roofFocus.x,e.y,roofFocus.z]};}
fs.writeFileSync(path.join(out,'roof-trees.json'),JSON.stringify({voxelCap:roofVoxelCap,trees:roofTrees,emissions:roofEmissions}));
manifest.vegetation=woodland.finish();
manifest.views.port={position:[-1190,430,A.edge(-1400,1)+210],target:[-1400,220,A.edge(-1400,1)-60]};
const stop=transport.nodes.find(n=>n.kind==='home'&&Math.abs(n.x)<1200);if(stop)manifest.views.rail={position:[stop.x+120,stop.y+95,stop.z+180],target:[stop.x,stop.y-8,stop.z]};
const farmStop=transport.nodes.find(n=>n.kind==='farm');if(farmStop)manifest.views.fieldport={position:[farmStop.x+130,farmStop.y+130,farmStop.z+200],target:[farmStop.x,farmStop.ground,farmStop.z]};
manifest.views.eastwater={position:[8200,1100,3700],target:[7100,60,1700]};


manifest.eyrieDetail=require('./atheria-eyrie-detail.cjs')({root,out,Mesh,model,A,site,tiles,aggregate});
manifest.eyrieTransition=require('./atheria-eyrie-transition.cjs').build({root,out,Mesh,model,A,site,tiles,aggregate});
manifest.views.eyrie={position:[-150,55,180],target:[0,-22,7]};
manifest.views.eyrieHome={position:[-25,17,33],target:[-1,3,2]};
manifest.views.eyrieCreek={position:[98,16,150],target:[26,-58,24]};
manifest.upland={northBankTargetM:390,flow:'Ishkar north distributary feeds Eyrie creek',feeder:'atheria-north-rill'};
fs.writeFileSync(path.join(out,'landscape-layout.json'),JSON.stringify({stats:model.landscape.stats,compounds:model.landscape.compounds,paths:model.landscape.paths,spaces:model.landscape.spaces}));
if(onlyTile){const before=previousManifest.tiles.find(t=>t.id===onlyTile),after=tiles.find(t=>t.id===onlyTile);if(!before||!after)throw Error('Unknown tile '+onlyTile);manifest.partialRebuild={tile:onlyTile,previousBuild:previousManifest.buildId,identicalMeshHashes:JSON.stringify(before.levels.map(l=>l.sha256))===JSON.stringify(after.levels.map(l=>l.sha256))};}
for(const [key,input]of Object.entries(inputSnapshot))if(sha(input.file)!==input.sha256)throw Error('Input changed during regional build: '+key+'; rebuild before publishing');
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest));fs.writeFileSync(path.join(out,'manifest.js'),'window.ATHERIA_REGION_MANIFEST='+JSON.stringify(manifest)+';');
require('./build-atheria-cliff-look.cjs').build(root,out);
fs.writeFileSync(path.join(out,'generation.json'),JSON.stringify({coverage,tiles:tiles.length,bytes:tiles.reduce((n,t)=>n+t.levels.reduce((a,l)=>a+l.bytes,0),0),triangles:tiles.reduce((n,t)=>n+t.levels[0].triangles,0)},null,2));console.log(JSON.stringify({out,tiles:tiles.length,coverage,complete:true}));
